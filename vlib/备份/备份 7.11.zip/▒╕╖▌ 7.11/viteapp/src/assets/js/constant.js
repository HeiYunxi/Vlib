// 全局变量
export default {
  name: '实训君',
  officialAccount: '实训技术'
}
